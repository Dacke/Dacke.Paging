﻿using Dapper;
using Dacke.Paging.Common.Enums;
using Dacke.Paging.Common.Interfaces;
using Dacke.Paging.Common.Cursor;

namespace Dacke.DapperPaging.Cursor.Filtering;

public static class DapperCursorFilteringExtensions {
    /// <summary>
    /// Applies filtering and keyset cursor boundary conditions from a PagedRequest and PagingContext 
    /// to generate a single combined SQL WHERE clause and Dapper DynamicParameters.
    /// </summary>
    public static (string WhereClause, DynamicParameters Parameters) BuildSqlWhere(this IFilterableRequest request, PagingContext pagingContext, Dictionary<string, string> propertyMap) {
        var parameters = new DynamicParameters();
        var filterConditions = new List<string>();
        var paramIndex = 0;

        ArgumentNullException.ThrowIfNull(request);

        // Build standard property filters
        if (request.Filters != null && request.Filters.Count > 0) {
            var globalFilterOperator = request.GlobalFilterOperator == FilterOperator.Any ? " OR " : " AND ";

            foreach (var filterRequest in request.Filters) {
                if (filterRequest == null || filterRequest.Constraints == null || filterRequest.Constraints.Count == 0)
                    continue;

                var constraintConditions = new List<string>();
                foreach (var constraint in filterRequest.Constraints) {
                    if (constraint == null || constraint.Value == null)
                        continue;

                    var stringValue = constraint.Value.ToString() ?? string.Empty;
                    if (string.IsNullOrWhiteSpace(stringValue) == true && constraint.MatchMode != MatchMode.Equals)
                        continue;

                    var paramName = $"@p_filter_{paramIndex++}";
                    var condition = BuildCondition(constraint.PropertyName, constraint.MatchMode, paramName, stringValue, constraint.Value, parameters);

                    if (string.IsNullOrEmpty(condition) == false)
                        constraintConditions.Add(condition);
                }

                if (constraintConditions.Count == 0)
                    continue;

                var logicalOperator = filterRequest.Operator == FilterOperator.Any ? " OR " : " AND ";
                var combinedCondition = constraintConditions.Count == 1
                    ? constraintConditions[0]
                    : $"({string.Join(logicalOperator, constraintConditions)})";

                filterConditions.Add(combinedCondition);
            }
        }

        var filterWhere = filterConditions.Count > 0
            ? string.Join(request.GlobalFilterOperator == FilterOperator.Any ? " OR " : " AND ", filterConditions)
            : string.Empty;

        // Build keyset cursor WHERE clause from pagingContext if a cursor is present
        string cursorWhereClause = string.Empty;
        if (pagingContext?.Cursor != null && pagingContext.SortColumns != null && pagingContext.SortColumns.Count > 0) {
            bool isBackward = pagingContext.NavigationDirection == NavigationDirection.Backward;
            var cursorClauses = new List<string>();

            // Map sort columns and build hierarchical keyset comparison (e.g., Col1 > @val1 OR (Col1 = @val1 AND Col2 > @val2)...)
            var sortColumns = pagingContext.SortColumns.ToList();
            var cursorValues = pagingContext.Cursor.SortValues?.ToList() ?? [];

            for (int i = 0; i < sortColumns.Count; i++) {
                var sortCol = sortColumns[i];
                var dbColumnName = propertyMap.TryGetValue(sortCol.PropertyName, out var mapped)
                    ? mapped
                    : sortCol.PropertyName;

                var safeCol = $"[{dbColumnName.Replace(";", "").Replace("'", "")}]";

                // Determine operator based on direction and sort direction
                bool descending = sortCol.Direction == SortDirection.Descending;
                string op = isBackward ? descending ? ">" : "<" : descending ? "<" : ">";
                var subConditions = new List<string>();

                // Equality checks for all preceding columns
                for (int j = 0; j < i; j++) {
                    var prevCol = sortColumns[j];
                    var prevDbCol = propertyMap.TryGetValue(prevCol.PropertyName, out var prevMapped)
                        ? prevMapped
                        : prevCol.PropertyName;
                    var safePrevCol = $"[{prevDbCol.Replace(";", "").Replace("'", "")}]";

                    var paramName = $"@p_cursor_eq_{paramIndex++}";
                    if (j < cursorValues.Count) {
                        parameters.Add(paramName, cursorValues[j].Value);
                        subConditions.Add($"{safePrevCol} = {paramName}");
                    }
                }

                // Inequality check for the current column
                var currParamName = $"@p_cursor_val_{paramIndex++}";
                if (i < cursorValues.Count) {
                    parameters.Add(currParamName, cursorValues[i].Value);
                    subConditions.Add($"{safeCol} {op} {currParamName}");
                }

                if (subConditions.Count == 1)
                    cursorClauses.Add(subConditions[0]);
                
                if (subConditions.Count > 1)
                    cursorClauses.Add($"({string.Join(" AND ", subConditions)})");
            }

            // Also include primary key fallback comparison if necessary
            if (cursorClauses.Count > 0)
                cursorWhereClause = string.Join(" OR ", cursorClauses);
        }

        // Combine filter conditions and cursor conditions into a single valid WHERE clause
        var combinedWhere = string.Empty;

        if (string.IsNullOrEmpty(filterWhere) == false && string.IsNullOrEmpty(cursorWhereClause) == false) {
            combinedWhere = $"WHERE {filterWhere} AND ({cursorWhereClause})";
        }
        else if (string.IsNullOrEmpty(filterWhere) == false) {
            combinedWhere = $"WHERE {filterWhere}";
        }
        else if (string.IsNullOrEmpty(cursorWhereClause) == false) {
            combinedWhere = $"WHERE {cursorWhereClause}";
        }

        return (combinedWhere, parameters);
    }

    private static string BuildCondition(string columnName, MatchMode matchMode, string paramName, string stringValue, object rawValue, DynamicParameters parameters) {
        var safeColumn = $"[{columnName.Replace(";", "").Replace("'", "")}]";

        switch (matchMode) {
            case MatchMode.Equals:
                parameters.Add(paramName, rawValue);
                return $"{safeColumn} = {paramName}";

            case MatchMode.NotEquals:
                parameters.Add(paramName, rawValue);
                return $"{safeColumn} != {paramName}";

            case MatchMode.Contains:
                parameters.Add(paramName, $"%{stringValue}%");
                return $"{safeColumn} LIKE {paramName}";

            case MatchMode.NotContains:
                parameters.Add(paramName, $"%{stringValue}%");
                return $"{safeColumn} NOT LIKE {paramName}";

            case MatchMode.StartsWith:
                parameters.Add(paramName, $"{stringValue}%");
                return $"{safeColumn} LIKE {paramName}";

            case MatchMode.EndsWith:
                parameters.Add(paramName, $"%{stringValue}");
                return $"{safeColumn} LIKE {paramName}";

            case MatchMode.LessThan:
                parameters.Add(paramName, rawValue);
                return $"{safeColumn} < {paramName}";

            case MatchMode.LessThanOrEqualTo:
                parameters.Add(paramName, rawValue);
                return $"{safeColumn} <= {paramName}";

            case MatchMode.GreaterThan:
                parameters.Add(paramName, rawValue);
                return $"{safeColumn} > {paramName}";

            case MatchMode.GreaterThanOrEqualTo:
                parameters.Add(paramName, rawValue);
                return $"{safeColumn} >= {paramName}";

            default:
                parameters.Add(paramName, rawValue);
                return $"{safeColumn} = {paramName}";
        }
    }
}