﻿using Dacke.Paging.Common.Cursor;
using Dacke.Paging.Common.Enums;

namespace Dacke.DapperPaging.Cursor.Sorting;

public static class DapperCursorSortingExtensions {
    /// <summary>
    /// Builds a SQL ORDER BY clause for cursor keyset pagination, automatically inverting 
    /// sort directions when navigating backwards.
    /// </summary>
    public static string BuildCursorSqlSorting(this PagedRequest request, PagingContext pagingContext, Dictionary<string, string>? propertyMap = null) {
        if (string.IsNullOrWhiteSpace(request.SortBy) == true)
            return string.Empty;

        var clauses = request.SortBy.Split(',', StringSplitOptions.RemoveEmptyEntries);
        var translatedClauses = new List<string>();

        string defaultDirectionText = request.DefaultSortDirection == SortDirection.Descending ? "DESC" : "ASC";

        foreach (var clause in clauses) {
            var parts = clause.Trim().Split(' ', StringSplitOptions.RemoveEmptyEntries);
            var propName = parts[0];

            string direction;
            if (parts.Length > 1 == true)
                direction = parts[1].ToUpperInvariant();
            else
                direction = defaultDirectionText;

            // Invert sort direction when paging backwards in keyset pagination
            var isBackward = request.NavigationDirection == NavigationDirection.Backward;
            if (isBackward)
                direction = direction == "ASC" ? "DESC" : "ASC";

            // Map DTO property names to database column names if a map is provided
            if (propertyMap != null && propertyMap.TryGetValue(propName, out var mappedName) == true)
                propName = mappedName;

            translatedClauses.Add($"{propName} {direction}");
        }

        return $"ORDER BY {string.Join(", ", translatedClauses)}";
    }
}
